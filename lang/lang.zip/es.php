<?php
    $lang = array();

    $lang["formName"] = "Nombre Completo";
    $lang["formAge"] = "Edad";
    $lang["formGender"] = "Género";
    $lang["formLocation"] = "Ciudad de Residencia";
    $lang["formNationality"] = "Nationalidad";
        $lang["formEducation"] = "Educación / Formación (completo)";
        $lang["formEducation_1"] = "Primaria"
        $lang["formEducation_2"] = "Secundaria"
        $lang["formEducation_3"] = "Terciario"
        $lang["formEducation_4"] = "Universitario"
        $lang["formEducation_5"] = "Master"
        $lang["formEducation_6"] = "Doctorado"
    $lang["formCareer"] = "Trabajo / Profesión";
        $lang["formLanguagesSpokenNative"] = "Idioma nativo";
    $lang["formStart"] = "Empezar";
    $lang["instructions"] = "Seleccione al menos uno o más puntos que usted crea interesantes en las siguientes imágenes:";
    $lang["next"] = "Siguiente";
    $lang["thanks"] = "Gracias por participar!";

?>
