<?php
    $lang = array();

    $lang["formName"] = "Full Name";
    $lang["formAge"] = "Age";
    $lang["formGender"] = "Gender";
    $lang["formLocation"] = "Location";
    $lang["formNationality"] = "Nationality";
        $lang["formEducation"] = "Education";
        $lang["formEducation_1"] = "Primary";
        $lang["formEducation_2"] = "Currently in High School";
        $lang["formEducation_3"] = "Secondary/High School Graduate";
        $lang["formEducation_4"] = "Associate in progress";
        $lang["formEducation_5"] = "Associate Degree";
        $lang["formEducation_6"] = "Bachelor in progress";
        $lang["formEducation_7"] = "Bachelor's or equivalent";
        $lang["formEducation_8"] = "Master in progress";
        $lang["formEducation_9"] = "Master's or equivalent";
        $lang["formEducation_10"] = "Doctorate in progress";
        $lang["formEducation_11"] = "Doctoral or equivalent";
    $lang["formAreaOfStudy"] = "Area of Study";
    $lang["formCareer"] = "Career/Job";
    $lang["formCulturalBackground"] = "Cultural Background – where is your family from?";
    $lang["formReligion"] = "Religion";
    $lang["formLanguagesSpoken"] = "Languages Spoken";
        $lang["formLanguagesSpokenNative"] = "- Native language";
        $lang["formLanguagesOthers"] = "- Others";
    $lang["formPeopleLiving"] = "How many people do you live with?";
        $lang["formPeopleLivingRelationship"] = "- Relationship with these people";
    $lang["formMaritalstatus"] = "Marital status";
    $lang["formStart"] = "Start";

    $lang["instructions"] = "Select at least one of (what you feel are) the most interesting points on the following image.";
    $lang["next"] = "Next";
    $lang["thanks"] = "Thank you for your participation!";

?>
